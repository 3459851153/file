<?php
include './data.php';
$arr = array();
foreach($data as $name=>$value){
    array_push($arr,$name);
}
$count = rand(0,count($arr));
print_r($data[$arr[$count]]["img"]);
?>