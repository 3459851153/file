<?php
$data =array(
'img1'=>array(
"img"=> "images/img(1).jpg",
),
'img2'=>array(
 "img"=> "images/img(2).jpg",
),

'img3'=>array(
    "img"=> "images/img(3).jpg",
    ),
    
'img4'=>array(
    "img"=> "images/img(4).jpg",
    ),
    
'img5'=>array(
    "img"=> "images/img(5).jpg",
    ),
    
'img6'=>array(
    "img"=> "images/img(6).jpg",
    ),
    
'img7'=>array(
    "img"=> "images/img(7).jpg",
    ),
    
'img8'=>array(
    "img"=> "images/img(8).jpg",
    ),
    
'img9'=>array(
    "img"=> "images/img(9).jpg",
    ),
    
'img10'=>array(
    "img"=> "images/img(10).jpg",
    ),
    
'img11'=>array(
    "img"=> "images/img(11).jpg",
    ),
    
'img12'=>array(
    "img"=> "images/img(12).jpg",
    ),
    
'img13'=>array(
    "img"=> "images/img(13).jpg",
    ),
    
'img14'=>array(
    "img"=> "images/img(14).jpg",
    ),
    
'img15'=>array(
    "img"=> "images/img(15).jpg",
    ),
    
'img16'=>array(
    "img"=> "images/img(16).jpg",
    ),
    
'img17'=>array(
    "img"=> "images/img(17).jpg",
    ),
    
'img18'=>array(
    "img"=> "images/img(18).jpg",
    ),
    
'img19'=>array(
    "img"=> "images/img(19).jpg",
    ),
    
'img20'=>array(
    "img"=> "images/img(20).jpg",
    ),)
?>